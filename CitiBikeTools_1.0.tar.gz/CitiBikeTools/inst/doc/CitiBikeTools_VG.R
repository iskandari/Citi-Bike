## ---- message = FALSE, warning = FALSE-----------------------------------

library(CitiBikeTools)
data(jsondata)

temp <- tempfile()

download.file("http://s3.amazonaws.com/tripdata/201307-citibike-tripdata.zip",temp, mode="wb")
unzip(temp, "2013-07 - Citi Bike trip data.csv")
Jul_2013 <- read.csv("2013-07 - Citi Bike trip data.csv")

download.file("http://s3.amazonaws.com/tripdata/201308-citibike-tripdata.zip",temp, mode="wb")
unzip(temp, "2013-08 - Citi Bike trip data.csv")
Aug_2013 <- read.csv("2013-08 - Citi Bike trip data.csv")


## ------------------------------------------------------------------------

first.year<- rbind(Jul_2013, Aug_2013)

rm(Jul_2013, Aug_2013)


## ------------------------------------------------------------------------

head(first.year$bikeid)


## ---- fig.width = 7, fig.height = 7--------------------------------------

library(CitiBikeTools)

one.bike(first.year, "2013-07-13 08:00:00", "2013-08-25 20:00:00",16223)

## ---- fig.width = 7, fig.height = 7--------------------------------------

zero.bike(jsondata, "W 52 St & 11 Ave")


## ---- fig.width = 7, fig.height = 7--------------------------------------

zero.bike(jsondata, "Christopher St & Greenwich St")


## ---- fig.width = 7, fig.height = 7--------------------------------------
net.demand(first.year, "2013-07-10 00:00:00", "2013-08-30 00:00:00", "Christopher St & Greenwich St")

## ---- fig.width = 7, fig.height = 7--------------------------------------
bike.pickups(first.year, "2013-07-10 00:00:00", "2013-08-30 00:00:00", "Christopher St & Greenwich St")

## ---- fig.width = 7, fig.height = 7--------------------------------------
bike.dropoffs(first.year, "2013-07-10 00:00:00", "2013-08-30 00:00:00", "Christopher St & Greenwich St")


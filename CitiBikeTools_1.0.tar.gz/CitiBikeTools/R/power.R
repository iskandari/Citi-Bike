
#' Empty station calculator 
#'
#' Takes in json data published by Open Bus (<http://data.beta.nyc/dataset/historical-machine-readable-citibike-data>).
#' Data is collected from the Citibike JSON feed at approximately 10-minute intervals
#' 
#' The function calculates the empty time of a particular station by aggregating then number of minutes that a station has 0 bikes empty over the data collection period
#' JSON data included in the CitiBikeTools package only includes data for March-June 2015 
#' @param data, a dataframe to be analyzed, i.e. jsondata
#' @param station_name, name of the CitiBike station to be analyzed 
#' @return Returns qplot with the aggregate number of minutes (approximated) that a station was empty by one-hour time intervals over an 24-period    
#' @export
zero.bike <- function(data, station_name){
  
one.station <- data[data$dock_name == station_name,]
one.station <- subset(one.station, avail_bikes == 0)
  
one.station$interval <- 10
  
sum <-aggregate(one.station$interval, 
                  list(as.POSIXlt(one.station$time)$hour), FUN=sum)
  
title <- paste("Total empty dock time", station_name)
qplot(sum$Group.1, sum$x, xlab = "time interval", ylab = "# of minutes empty", main = title, label = sum$x) + geom_line(size = 2, color = "red") + scale_x_continuous(breaks=0:23) + geom_text(color = "dark blue", size = 4, hjust = 1, vjust = 2.0) + geom_point()
}
#' One bike distance calculator
#'
#'Calculates euclidean and Manhattan distance of the path travelled by a particular bike during a specific period of time and displays the geometric path overlayed on a map of New York (Google maps). 
#'Takes a data frame dervied from system data published by CitiBike (http://www.citibikenyc.com/system-data). See vignette for codes to download directly from the CitiBike website into R.  
#'
#'@param data, A dataframe to be analyzed, i.e. first.year (see vignette)
#'@param start, The beginning of the period of analysis in POSIX format (e.g. "2013-08-01 08:00:00")
#'@param end, The end of the period of analysis in POSIX format (e.g. "2013-09-01 08:00:00")
#'@param bikeid, An integer corresponding to the bike id of a particular bike in the system (e.g. 19213). For a list of unique bike ids, input unique(first.year$bikeid)
#'@param threshold, A numeric value referring to the threshold number of kilometers a bike has traveled, over which it is no longer safe to ride the bike as it requires maintenance.  Default is 1500. 
#'@return Number of trips taken by a bike, euclidean distance travelled in km, Manhattan distance travelled in km, the average speed of the bike based on $tripduration, and binary output of SAFE/MAINTAIN based on whether the Manhattan distance surpassed the threshold value   
#'@references <http://www.citibikenyc.com/system-data>
#'@export 

one.bike <- function(data, start, end, bikeid, threshold=1500){
  
  onebike = data[data$bikeid == bikeid,]
  
  start.date <- strptime(x = as.character(onebike$starttime), format = "%Y-%m-%d %H:%M:%S",)
  end.date <- strptime(x = as.character(onebike$stoptime), format = "%Y-%m-%d %H:%M:%S",)
  onebike$starttime <- start.date
  onebike$stoptime <- end.date 
  
  onebike <- onebike[onebike$starttime >= start & onebike$starttime <= end,]
  
  if(nrow(onebike) == 0) {stop("BIKE INACTIVE DURING SELECTED TIME PERIOD")}
  
  onebike <- na.omit(onebike)
  
  df.Start <<- as.data.frame(cbind(onebike$start.station.longitude, onebike$start.station.latitude))
  df.End <- as.data.frame(cbind(onebike$end.station.longitude, onebike$end.station.latitude))
  dist <- distHaversine((df.Start[1:nrow(df.Start),]), df.End[1:nrow(df.End),], r=6378137)
  
  first.path <- onebike[c("start.station.latitude", "start.station.longitude", "end.station.latitude", "end.station.longitude")]
  minlat <- min(first.path$start.station.latitude) 
  maxlat <- max(first.path$start.station.latitude) 
  minlon <- min(first.path$start.station.longitude) 
  maxlon <- max(first.path$start.station.longitude) 
  
  title <- paste("Path of bike #", bikeid)
  
  basemap <- get_map(location=c(minlon, minlat, maxlon, maxlat), zoom = 13, color = "bw")
  mapl <- ggmap(basemap, extent='panel', base_layer=ggplot(df.Start, aes(x=V1, y=V2)))
  map.df <- mapl + geom_point(color = "orange", size = 3) + geom_path(data=df.Start, aes(x=V1, y=V2), color="black", size = .2) + ggtitle(title) + xlab("Long") +ylab("Lat")
  
  print(paste("Number of Trips:",length(dist)))
  print(map.df)
  total_dist = round(sum(dist)/1000, 2)
  dist_manhattan = 2*sqrt(dist^2/2)
  total_manhattan_dist = round(sum(dist_manhattan)/1000, 2)
  print(paste("Euclidean distance travelled (km):", total_dist))
  print(paste("Manhattan distance travelled (km):", total_manhattan_dist))
  tripduration <- onebike$tripduration
  avg.speed <- round(mean((dist/tripduration)*3.6), 2) 
  print(paste("Average Speed (km/h):", avg.speed))
  
  if (total_manhattan_dist > threshold) {   
    print("MAINTAIN")
  } else {
    print("SAFE")
  }
}

# calculates total pickups - total dropoffs for a particular station for a defined period of time 
# prints plot of net demand with best fit line

#' Net demand calculator 
#'
#' Calclates the daily net demand of bikes (pickups minus returns during observation period) at a specified station.  Net demand implies that after a pickup and a return occur, the inventory is unchanged and net demand = 0. 

#' @param data, A dataframe proided by CitiBike to be analyzed, i.e. first.year  
#' @param start, The beginning of the period of analysis in POSIX format (e.g. "2013-08-01 08:00:00")  
#' @param end, The end of the period of analysis in POSIX format (e.g. "2013-09-01 08:00:00")
#' @param station.id, The name of a station as it appears in CitiBike datasets (i.e. "1 Ave & E 15 St" or "Broadway & W 60 St).  For a list of all unique stations, use unique()
#' @return Returns a qplot of net demand and a list of daily net demand over the observation period.   
#' @references New York City Bike Share Data: Methodology. The Open Bus. 2015. <http://www.theopenbus.com/uploads/2/8/5/5/28559839/bike_methodology.pdf>
#' @export
net.demand <- function(data, start, end, station.id){
  
  data1 <- data[data$start.station.name == station.id | data$end.station.name == station.id,]
  
  start.date <- strptime(x = as.character(data1$starttime), format = "%Y-%m-%d %H:%M:%S")
  end.date <- strptime(x = as.character(data1$stoptime), format = "%Y-%m-%d %H:%M:%S")
  data1$starttime <- start.date
  data1$stoptime <- end.date 
  
  data1 <- data1[data1$starttime >= start & data1$starttime <= end, ]
  
  data1 <- na.omit(data1)
  
  split.date <- split(data1, as.Date(data1$starttime))
  
  net_demand <- sapply(split.date, function(x) {
    
    day_data <- x
    
    starts <- day_data[day_data$start.station.name == station.id,]
    ends <- day_data[day_data$end.station.name == station.id,]
    (nrow(starts)-nrow(ends))
    
  })
  
  title <- paste("Net demand @ ", station.id)
  time <- paste(" from ", start, " to ", end)
  
  new_net_demand <- as.data.frame(net_demand)
  new_net_demand$day <- row.names(new_net_demand)
  new_net_demand <- new_net_demand[c("day", "net_demand")]
  day<-strptime(new_net_demand$day,format="%Y-%m-%d")
  day <- as.POSIXct(day)
  new_net_demand$day <- day
  
  print(net_demand)
  
  ggplot(new_net_demand, aes(x=day, y=net_demand)) +
    geom_point(shape=1) +    # Use hollow circles
    stat_smooth(aes(y = net_demand), method=lm, formula = y ~ poly(x,2), level=0.95) + geom_line(col = "grey") + ggtitle(title)
  
}

#' Bike pickups calculator
#'
#' Aggregates the daily number of bike pickups at a particular station over an observation period.  
#'@param data, A dataframe proided by CitiBike to be analyzed, (i.e. first.year)  
#'@param start, The beginning of the period of analysis in POSIX format (e.g. "2013-08-01 08:00:00")  
#'@param end, The end of the period of analysis in POSIX format (e.g. "2013-09-01 08:00:00")
#'@param station.id, The name of a station as it appears in CitiBike datasets (i.e. "1 Ave & E 15 St" or "Broadway & W 60 St).  For a list of all unique stations, use unique(jsondata$dock_name)
#'@return Returns a qplot of pickups and a list of daily pickups over the observation period.   
#'@references New York City Bike Share Data: Methodology. The Open Bus. 2015. <http://www.theopenbus.com/uploads/2/8/5/5/28559839/bike_methodology.pdf>
#'@export
bike.pickups <- function(data, start, end, station.id){
  
  data1 <- data[data$start.station.name == station.id | data$end.station.name == station.id,]
  
  start.date <- strptime(x = as.character(data1$starttime), format = "%Y-%m-%d %H:%M:%S")
  end.date <- strptime(x = as.character(data1$stoptime), format = "%Y-%m-%d %H:%M:%S")
  data1$starttime <- start.date
  data1$stoptime <- end.date 
  
  data1 <- data1[data1$starttime >= start & data1$starttime <= end, ]
  
  data1 <- na.omit(data1)
  
  split.date <- split(data1, as.Date(data1$starttime))
  
  pickups <- sapply(split.date, function(x) {
    
    day_data <- x
    
    starts <- day_data[day_data$start.station.name == station.id,]
    ends <- day_data[day_data$end.station.name == station.id,]
    (nrow(starts))
    
  })
  title <- paste("Total pickups over time @ ", station.id)
  time <- paste(" from ", start, " to ", end)
  
  new_pickups <- as.data.frame(pickups)
  new_pickups$day <- row.names(new_pickups)
  new_pickups <- new_pickups[c("day", "pickups")]
  day<-strptime(new_pickups$day,format="%Y-%m-%d")
  day <- as.POSIXct(day)
  new_pickups$day <- day
  
  print(pickups)
  
  ggplot(new_pickups, aes(x=day, y=pickups)) +
    geom_point(shape=1) +    # Use hollow circles
    stat_smooth(aes(y = pickups), method=lm, formula = y ~ poly(x,2), level=0.95) + geom_line(col = "grey") + ggtitle(title)
  
}

#' Bike drop-offs calculator
#'
#' Aggregates the daily number of bike drop-offs at a particular station over an observation period.  
#'@param data, A dataframe proided by CitiBike to be analyzed, (i.e. first.year)  
#'@param start, The beginning of the period of analysis in POSIX format (e.g. "2013-08-01 08:00:00")  
#'@param end, The end of the period of analysis in POSIX format (e.g. "2013-09-01 08:00:00")
#'@param station.id, The name of a station as it appears in CitiBike datasets (i.e. "1 Ave & E 15 St" or "Broadway & W 60 St).  For a list of all unique stations, use unique(jsondata$dock_name)
#'@return Returns a qplot of drop-offs and a list of daily drop-offs over the observation period.   
#'@references New York City Bike Share Data: Methodology. The Open Bus. 2015. <http://www.theopenbus.com/uploads/2/8/5/5/28559839/bike_methodology.pdf>
#'@export
bike.dropoffs <- function(data, start, end, station.id){
  
  data1 <- data[data$start.station.name == station.id | data$end.station.name == station.id,]
  
  start.date <- strptime(x = as.character(data1$starttime), format = "%Y-%m-%d %H:%M:%S")
  end.date <- strptime(x = as.character(data1$stoptime), format = "%Y-%m-%d %H:%M:%S")
  data1$starttime <- start.date
  data1$stoptime <- end.date 
  
  data1 <- data1[data1$starttime >= start & data1$starttime <= end, ]
  
  data1 <- na.omit(data1)
  
  split.date <- split(data1, as.Date(data1$starttime))
  
  dropoffs <- sapply(split.date, function(x) {
    
    day_data <- x
    
    starts <- day_data[day_data$start.station.name == station.id,]
    ends <- day_data[day_data$end.station.name == station.id,]
    (nrow(ends))
    
  })
  title <- paste("Total dropoffs over time @ ", station.id)
  time <- paste(" from ", start, " to ", end)
  
  new_dropoffs <- as.data.frame(dropoffs)
  new_dropoffs$day <- row.names(new_dropoffs)
  new_dropoffs <- new_dropoffs[c("day", "dropoffs")]
  day<-strptime(new_dropoffs$day,format="%Y-%m-%d")
  day <- as.POSIXct(day)
  new_dropoffs$day <- day
  
  print(dropoffs)
  
  ggplot(new_dropoffs, aes(x=day, y=dropoffs)) +
    geom_point(shape=1) +    # Use hollow circles
    stat_smooth(aes(y = dropoffs), method=lm, formula = y ~ poly(x,2), level=0.95) + geom_line(col = "grey") + ggtitle(title)
  
}

# 

#' Mean
#'
#' Takes the mean of the input values   
#'@param x, Takes data frame of CitiBike system data
#'@rdname mean
#'@return Returns the mean of values in vector x 
#'@export
mean <- 
  function(x){
    UseMethod("mean")
  }

#' Mean duration calculator
#' 
#' Takes the mean duration of bike trips over the observation period. 
#'@return \code{NULL}
#'@rdname mean.duration
#'@param x, Input data frame first.year
#'@param bikeid,  Returns the average trip duration of all trips taken by a particular bike in the observation period 
#'@method mean duration
#'@export

# mean.duration <- function(x, bikeid){
#   UseMethod("mean")
#   duration_function <- x[x$bikeid == bikeid, ]
#   duration <- mean(duration_function$tripduration)
#   print(paste("Mean duration:", duration, "seconds"))
# }

#' jsondata 
#'
#' A dataset containing time stamped raw data providing station conditions through time.  
#' The variables are as follows: 
#'
#'\itemize{
#'  \item dock_id: official dock id provided by Citi Bike 
#'  \item dock_name: official dock name provided by Citi Bike
#'  \item time: Year-month-day hour:minute:second POSIX format
#'  \item avail_bikes: number of avialable bikes
#'  \item avail_docks: numbe of available (empty) docks
#'  \item tot_docks: number of functioning (online) docks
#'  \item X_lat: decimal degrees latitude of station
#'  \item X_lon: decimal degrees longitude of station  
#'  \item in_service: 1 means in service, 0 means out of service
#'  \item status_key: always 1
#'}
#'@docType data
#'@keywords datasets
#'@name jsondata
#'@usage data(jsondata)
#'@format A data frame with 5250940 rows and 10 variables

NULL

